﻿namespace Sales_Report
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            txtViernes = new TextBox();
            txtJueves = new TextBox();
            txtMiercoles = new TextBox();
            txtMartes = new TextBox();
            txtLunes = new TextBox();
            txtItem = new TextBox();
            btnSubmitItem = new Button();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            label7 = new Label();
            label8 = new Label();
            lblGrossSales = new Label();
            lstvResults = new ListView();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.Gainsboro;
            groupBox1.Controls.Add(txtViernes);
            groupBox1.Controls.Add(txtJueves);
            groupBox1.Controls.Add(txtMiercoles);
            groupBox1.Controls.Add(txtMartes);
            groupBox1.Controls.Add(txtLunes);
            groupBox1.Controls.Add(txtItem);
            groupBox1.Controls.Add(btnSubmitItem);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Font = new Font("Tahoma", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(9, 13);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(242, 334);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Input Item";
            // 
            // txtViernes
            // 
            txtViernes.BorderStyle = BorderStyle.FixedSingle;
            txtViernes.Location = new Point(139, 249);
            txtViernes.Name = "txtViernes";
            txtViernes.Size = new Size(90, 26);
            txtViernes.TabIndex = 12;
            // 
            // txtJueves
            // 
            txtJueves.BorderStyle = BorderStyle.FixedSingle;
            txtJueves.Location = new Point(139, 206);
            txtJueves.Name = "txtJueves";
            txtJueves.Size = new Size(90, 26);
            txtJueves.TabIndex = 11;
            // 
            // txtMiercoles
            // 
            txtMiercoles.BorderStyle = BorderStyle.FixedSingle;
            txtMiercoles.Location = new Point(140, 163);
            txtMiercoles.Name = "txtMiercoles";
            txtMiercoles.Size = new Size(90, 26);
            txtMiercoles.TabIndex = 10;
            // 
            // txtMartes
            // 
            txtMartes.BorderStyle = BorderStyle.FixedSingle;
            txtMartes.Location = new Point(140, 121);
            txtMartes.Name = "txtMartes";
            txtMartes.Size = new Size(90, 26);
            txtMartes.TabIndex = 9;
            // 
            // txtLunes
            // 
            txtLunes.BorderStyle = BorderStyle.FixedSingle;
            txtLunes.Location = new Point(140, 79);
            txtLunes.Name = "txtLunes";
            txtLunes.Size = new Size(90, 26);
            txtLunes.TabIndex = 8;
            // 
            // txtItem
            // 
            txtItem.BackColor = SystemColors.Window;
            txtItem.BorderStyle = BorderStyle.FixedSingle;
            txtItem.Location = new Point(104, 32);
            txtItem.Name = "txtItem";
            txtItem.Size = new Size(125, 26);
            txtItem.TabIndex = 7;
            // 
            // btnSubmitItem
            // 
            btnSubmitItem.Location = new Point(104, 292);
            btnSubmitItem.Name = "btnSubmitItem";
            btnSubmitItem.Size = new Size(126, 29);
            btnSubmitItem.TabIndex = 6;
            btnSubmitItem.Text = "Submit Item";
            btnSubmitItem.UseVisualStyleBackColor = true;
            btnSubmitItem.Click += btnSubmitItem_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(15, 252);
            label6.Name = "label6";
            label6.Size = new Size(52, 18);
            label6.TabIndex = 5;
            label6.Text = "Friday:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(15, 209);
            label5.Name = "label5";
            label5.Size = new Size(75, 18);
            label5.TabIndex = 4;
            label5.Text = "Thursday:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(15, 166);
            label4.Name = "label4";
            label4.Size = new Size(85, 18);
            label4.TabIndex = 3;
            label4.Text = "Wednesday";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(15, 124);
            label3.Name = "label3";
            label3.Size = new Size(70, 18);
            label3.TabIndex = 2;
            label3.Text = "Tuesday:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(15, 82);
            label2.Name = "label2";
            label2.Size = new Size(65, 18);
            label2.TabIndex = 1;
            label2.Text = "Monday:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(15, 36);
            label1.Name = "label1";
            label1.Size = new Size(45, 18);
            label1.TabIndex = 0;
            label1.Text = "Item:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Tahoma", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.Location = new Point(280, 13);
            label7.Name = "label7";
            label7.Size = new Size(108, 18);
            label7.TabIndex = 2;
            label7.Text = "Itemized Sales:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Tahoma", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.Location = new Point(640, 330);
            label8.Name = "label8";
            label8.Size = new Size(88, 18);
            label8.TabIndex = 3;
            label8.Text = "Gross Sales:";
            // 
            // lblGrossSales
            // 
            lblGrossSales.BorderStyle = BorderStyle.FixedSingle;
            lblGrossSales.Font = new Font("Tahoma", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblGrossSales.Location = new Point(734, 329);
            lblGrossSales.Name = "lblGrossSales";
            lblGrossSales.Size = new Size(142, 28);
            lblGrossSales.TabIndex = 13;
            // 
            // lstvResults
            // 
            lstvResults.FullRowSelect = true;
            lstvResults.Location = new Point(272, 34);
            lstvResults.Name = "lstvResults";
            lstvResults.Size = new Size(604, 292);
            lstvResults.TabIndex = 14;
            lstvResults.UseCompatibleStateImageBehavior = false;
            lstvResults.View = View.Details;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Gainsboro;
            ClientSize = new Size(881, 366);
            Controls.Add(lstvResults);
            Controls.Add(lblGrossSales);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(groupBox1);
            Font = new Font("Nirmala Text", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            Name = "Form1";
            Text = "Sales Report";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private TextBox txtViernes;
        private TextBox txtJueves;
        private TextBox txtMiercoles;
        private TextBox txtMartes;
        private TextBox txtLunes;
        private TextBox txtItem;
        private Button btnSubmitItem;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Label label7;
        private Label label8;
        private Label lblGrossSales;
        private ListView lstvResults;
    }
}
