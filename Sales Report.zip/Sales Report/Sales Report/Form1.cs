//Un fabricante de ropa le ha pedido que cree un Aplicaci�n que calcular� las ventas totales de ese 
//fabricante en una semana. Valores de ventas debe ingresarse por separado para cada prenda de 
//vestir, pero la cantidad de ventas para los cinco d�as de la semana debe ingresarse de inmediato. 
//La aplicaci�n debe calcular el monto total de ventas de cada art�culo en la semana y tambi�n 
//calcular las ventas totales del fabricante para todos los art�culos en la semana. Como el fabricante 
//es una empresa peque�a, producir� como m�ximo diez art�culos  en cualquier semana.


namespace Sales_Report
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Columnas
        private void Form1_Load(object sender, EventArgs e)
        {
            lstvResults.Columns.Add("Name", 80);
            lstvResults.Columns.Add("Mon", 80);
            lstvResults.Columns.Add("Tue", 80);
            lstvResults.Columns.Add("Wed", 80);
            lstvResults.Columns.Add("Thu", 80);
            lstvResults.Columns.Add("Fri", 80);
            lstvResults.Columns.Add("Total", 100);
        }

        //Declarar arreglo bidimensional para almacenar
        //Maximo 10 items
        string[,] sales = new string[10, 7];

        //Constantes
        const int item = 0;
        const int lunes = 1;
        const int martes = 2;
        const int miercoles = 3;
        const int jueves = 4;
        const int viernes = 5;
        const int total = 6;

        //Contenedor del numero de items introducidos
        int contadorItems = 0;

        //Calcular el total de la semana
        public double CalcularTotalSemana(double lunes, double martes, double miercoles, double jueves, double viernes)
        {
            return lunes + martes + miercoles + jueves + viernes;
        }

        //Mostrar itmes y totales
        public void MostrarResultados()
        {
            //Limpiar la lista
            lstvResults.Items.Clear();

            //Sumar y promediar totales
            double totalGeneral = 0;

            //Recorre el arreglo
            for (int i = 0; i < contadorItems; i++)
            {
                //Mostrar en el arreglo
                ListViewItem Litem = new ListViewItem(sales[i, item]); 
                Litem.SubItems.Add("$" + Convert.ToDouble(sales[i, lunes]).ToString("F2"));
                Litem.SubItems.Add("$" + Convert.ToDouble(sales[i, martes]).ToString("F2"));
                Litem.SubItems.Add("$" + Convert.ToDouble(sales[i, miercoles]).ToString("F2"));
                Litem.SubItems.Add("$" + Convert.ToDouble(sales[i, jueves]).ToString("F2"));
                Litem.SubItems.Add("$" + Convert.ToDouble(sales[i, viernes]).ToString("F2"));
                Litem.SubItems.Add("$" + Convert.ToDouble(sales[i, total]).ToString("F2"));
                lstvResults.Items.Add(Litem);

                //Acumular promedio
                totalGeneral += Convert.ToDouble(sales[i, total]);

                //Calculo y muestra
                lblGrossSales.Text = "$" + totalGeneral.ToString();
            }
        }

        private void btnSubmitItem_Click(object sender, EventArgs e)
        {
            try
            {
                //Obtener valores
                double lu = Convert.ToDouble(txtLunes.Text);
                double ma = Convert.ToDouble(txtMartes.Text);
                double mi = Convert.ToDouble(txtMiercoles.Text);
                double ju = Convert.ToDouble(txtJueves.Text);
                double vi = Convert.ToDouble(txtViernes.Text);

                double totalSemana = lu + ma + mi + ju + vi;

                //Anadir al arreglo
                sales[contadorItems, item] = txtItem.Text;
                sales[contadorItems, lunes] = lu.ToString();
                sales[contadorItems, martes] = ma.ToString();
                sales[contadorItems, miercoles] = mi.ToString();
                sales[contadorItems, jueves] = ju.ToString();
                sales[contadorItems, viernes] = vi.ToString();
                sales[contadorItems, total] = totalSemana.ToString();
                //Incrementar el contador 
                contadorItems++;

                //Resultados
                MostrarResultados();

                // Limpiar textboxes
                txtItem.Clear();
                txtLunes.Clear();
                txtMartes.Clear();
                txtMiercoles.Clear();
                txtJueves.Clear();
                txtViernes.Clear();
            }
            catch (Exception)
            {
                MessageBox.Show("Inserte valores validos");
            }
        }
    }
}
