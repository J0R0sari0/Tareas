namespace Temporizador
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string tiempo = "";
        Tiempo objTiempo;

        //metodo Displaytime para convertir un texto en representacion de hh:mm:ss
        private void DisplayTime()
        {
            int horas, minutos, segundos;

            if (tiempo.Length > 5)
            {
                tiempo = tiempo.Substring(0, 5);
            }

            string display;
            display = tiempo.PadLeft(5, '0');


            horas = int.Parse(display.Substring(0, 1));
            minutos = int.Parse(display.Substring(1, 2));
            segundos = int.Parse(display.Substring(3, 2));

            if (minutos > 59)
            {
                minutos = 59;
            }
            if (segundos > 59)
            {
                segundos = 59;
            }

            lblPantalla.Text = $"{horas:D2}:{minutos:D2}:{segundos:D2}";
        }

        private void NumberBTN_Click(object sender, EventArgs e)
        {
            tiempo += (sender as Button).Text;
            DisplayTime();
        }



        private void btnInsertar_Click(object sender, EventArgs e)
        {
            if (objTiempo == null || objTiempo.Empty())
            {
                //Debemos descomponer el tiempo que el usuario digita como string
                int horas, minutos, segundos;

                tiempo = tiempo.PadLeft(5, '0');

                horas = int.Parse(tiempo.Substring(0, 1));
                minutos = int.Parse(tiempo.Substring(1, 2));
                segundos = int.Parse(tiempo.Substring(3, 2));

                objTiempo = new Tiempo(horas, minutos, segundos);

            }


            //mostramos el objeto en la pantalla

            lblPantalla.Text = $"{objTiempo.Horas:D2}:{objTiempo.Minutos:D2}:{objTiempo.Segundos:D2}";

            timer1.Enabled = true;

            pnlPantalla.BackColor = Color.Yellow;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //decrementamos las propiedades del objeto objTiempo
            if (objTiempo.Segundos > 0)
            {
                objTiempo.Segundos--;
            }
            else if (objTiempo.Minutos > 0)
            {
                objTiempo.Minutos--;
                objTiempo.Segundos = 59;
            }
            else if (objTiempo.Horas > 0)
            {
                objTiempo.Horas--;
                objTiempo.Minutos = 59;
                objTiempo.Segundos = 59;
            }
            else
            {
                timer1.Enabled = false;
                tiempo = "";
                pnlPantalla.BackColor = SystemColors.Control;
            }

            if (objTiempo.Horas == 0 && objTiempo.Minutos == 0 && objTiempo.Segundos == 0)
            {
                lblPantalla.Text = "Finished";
            }
            else
            {
                lblPantalla.Text = $"{objTiempo.Horas:D2}:{objTiempo.Minutos:D2}:{objTiempo.Segundos:D2}";
            }


        }

        private void btnDetener_Click(object sender, EventArgs e)
        {
            if (timer1.Enabled)
            {
                timer1.Enabled = false;
            }
            else
            {
                tiempo = "";
                objTiempo.Reset();
                lblPantalla.Text = $"00:00:00";
            }
            pnlPantalla.BackColor = SystemColors.Control;
        }
    }
}
