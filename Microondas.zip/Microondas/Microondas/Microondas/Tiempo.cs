﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Temporizador
{
    internal class Tiempo
    {
        private int horas;
        private int minutos;
        private int segundos;

        public int Horas
        {
            get { return horas; }
            set
            {
                if (value < 10)
                {
                    horas = value;
                }
                else
                {
                    horas = 0;
                }
            }
        }

        public int Minutos
        {
            get { return minutos; }
            set
            {
                if (value < 60)
                {
                    minutos = value;
                }
                else
                {
                    minutos = 0;
                }
            }
        }

        public int Segundos
        {
            get { return segundos; }
            set
            {
                if (value < 60)
                {
                    segundos = value;
                }
                else
                {
                    segundos = 0;
                }
            }
        }
        //constructor
        public Tiempo(int horas, int minutos, int segundos)
        {
            Horas = horas;
            Minutos = minutos;
            Segundos = segundos;
        }

        public void Reset()
        {
            Horas = 0;
            Minutos = 0;
            Segundos = 0;
        }

        public bool Empty()
        {
            if (Horas > 0 || Minutos > 0 || Segundos > 0)
            {
                return false;
            }
            return true;
        }
    }
}
