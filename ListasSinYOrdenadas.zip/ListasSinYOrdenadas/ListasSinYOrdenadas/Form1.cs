using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace ListasSinYOrdenadas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void btnAnadirSinOrdenr_Click_1(object sender, EventArgs e)
        {
            string input = Interaction.InputBox("Ingrese un elemento:");
            if (!string.IsNullOrWhiteSpace(input))
            lstSinOrdenar.Items.Add(input);
        }

        private void btnBorrarSinOrdenar_Click_1(object sender, EventArgs e)
        {
            if (lstSinOrdenar.SelectedItem != null)
            lstSinOrdenar.Items.Remove(lstSinOrdenar.SelectedItem);
        }

        private void btnBorrarLstSinOrdenar_Click_1(object sender, EventArgs e)
        {
            lstSinOrdenar.Items.Clear();
        }

        private void btnAnadirOrdenada_Click_1(object sender, EventArgs e)
        {
            string input = Interaction.InputBox("Ingrese el/los elementos (Si son varios separar por una coma): ");
            if (!string.IsNullOrWhiteSpace(input))
            {
                string[] elementos = input.Split(',');
                foreach (string item in elementos)
                {
                    string trimmed = item.Trim();
                    if (!string.IsNullOrEmpty(trimmed))
                        lstOrdenada.Items.Add(trimmed);
                }
                OrdenarListaOrdenada();
            }
        }

        private void btnBorrarOrdenada_Click_1(object sender, EventArgs e)
        {
            while (lstOrdenada.SelectedItems.Count > 0)
            lstOrdenada.Items.Remove(lstOrdenada.SelectedItems[0]);
        }

        private void btnBorrarLstOrdenada_Click_1(object sender, EventArgs e)
        {
            lstOrdenada.Items.Clear();
        }

        private void btnMoveToLeft_Click_1(object sender, EventArgs e)
        {
            while (lstOrdenada.SelectedItems.Count > 0)
            {
                lstSinOrdenar.Items.Add(lstOrdenada.SelectedItems[0].ToString());
                lstOrdenada.Items.Remove(lstOrdenada.SelectedItems[0]);
            }
        }

        private void btnMoveToRight_Click_1(object sender, EventArgs e)
        {
            if (lstSinOrdenar.SelectedItem != null)
            {
                lstOrdenada.Items.Add(lstSinOrdenar.SelectedItem.ToString());
                lstSinOrdenar.Items.Remove(lstSinOrdenar.SelectedItem);
                OrdenarListaOrdenada();
            }
        }

        private void OrdenarListaOrdenada()
        {
            List<string> items = lstOrdenada.Items.Cast<string>().ToList();
            items.Sort();
            lstOrdenada.Items.Clear();
            foreach (string item in items)
                lstOrdenada.Items.Add(item);
        }

    }
}