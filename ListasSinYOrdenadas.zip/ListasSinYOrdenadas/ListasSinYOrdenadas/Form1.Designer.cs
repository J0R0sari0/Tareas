﻿namespace ListasSinYOrdenadas
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            btnMoveToLeft = new Button();
            btnMoveToRight = new Button();
            btnAnadirSinOrdenr = new Button();
            btnBorrarSinOrdenar = new Button();
            btnBorrarLstSinOrdenar = new Button();
            btnAnadirOrdenada = new Button();
            btnBorrarOrdenada = new Button();
            btnBorrarLstOrdenada = new Button();
            lstSinOrdenar = new ListBox();
            lstOrdenada = new ListBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(71, 63);
            label1.Name = "label1";
            label1.Size = new Size(181, 24);
            label1.TabIndex = 0;
            label1.Text = "Lista sin Ordenar";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(480, 63);
            label2.Name = "label2";
            label2.Size = new Size(162, 24);
            label2.TabIndex = 1;
            label2.Text = "Lista Ordenada";
            // 
            // btnMoveToLeft
            // 
            btnMoveToLeft.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnMoveToLeft.Location = new Point(313, 260);
            btnMoveToLeft.Name = "btnMoveToLeft";
            btnMoveToLeft.Size = new Size(90, 60);
            btnMoveToLeft.TabIndex = 2;
            btnMoveToLeft.Text = "<<";
            btnMoveToLeft.UseVisualStyleBackColor = true;
            btnMoveToLeft.Click += btnMoveToLeft_Click_1;
            // 
            // btnMoveToRight
            // 
            btnMoveToRight.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnMoveToRight.Location = new Point(313, 326);
            btnMoveToRight.Name = "btnMoveToRight";
            btnMoveToRight.Size = new Size(90, 59);
            btnMoveToRight.TabIndex = 3;
            btnMoveToRight.Text = ">>";
            btnMoveToRight.UseVisualStyleBackColor = true;
            btnMoveToRight.Click += btnMoveToRight_Click_1;
            // 
            // btnAnadirSinOrdenr
            // 
            btnAnadirSinOrdenr.Font = new Font("Tahoma", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAnadirSinOrdenr.Location = new Point(29, 536);
            btnAnadirSinOrdenr.Name = "btnAnadirSinOrdenr";
            btnAnadirSinOrdenr.Size = new Size(254, 29);
            btnAnadirSinOrdenr.TabIndex = 4;
            btnAnadirSinOrdenr.Text = "Anadir Elemento";
            btnAnadirSinOrdenr.UseVisualStyleBackColor = true;
            btnAnadirSinOrdenr.Click += btnAnadirSinOrdenr_Click_1;
            // 
            // btnBorrarSinOrdenar
            // 
            btnBorrarSinOrdenar.Font = new Font("Tahoma", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBorrarSinOrdenar.Location = new Point(29, 585);
            btnBorrarSinOrdenar.Name = "btnBorrarSinOrdenar";
            btnBorrarSinOrdenar.Size = new Size(254, 29);
            btnBorrarSinOrdenar.TabIndex = 5;
            btnBorrarSinOrdenar.Text = "Borrar Elemento";
            btnBorrarSinOrdenar.UseVisualStyleBackColor = true;
            btnBorrarSinOrdenar.Click += btnBorrarSinOrdenar_Click_1;
            // 
            // btnBorrarLstSinOrdenar
            // 
            btnBorrarLstSinOrdenar.Font = new Font("Tahoma", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBorrarLstSinOrdenar.Location = new Point(29, 636);
            btnBorrarLstSinOrdenar.Name = "btnBorrarLstSinOrdenar";
            btnBorrarLstSinOrdenar.Size = new Size(254, 29);
            btnBorrarLstSinOrdenar.TabIndex = 6;
            btnBorrarLstSinOrdenar.Text = "Borrar Lista";
            btnBorrarLstSinOrdenar.UseVisualStyleBackColor = true;
            btnBorrarLstSinOrdenar.Click += btnBorrarLstSinOrdenar_Click_1;
            // 
            // btnAnadirOrdenada
            // 
            btnAnadirOrdenada.Font = new Font("Tahoma", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAnadirOrdenada.Location = new Point(437, 536);
            btnAnadirOrdenada.Name = "btnAnadirOrdenada";
            btnAnadirOrdenada.Size = new Size(254, 29);
            btnAnadirOrdenada.TabIndex = 7;
            btnAnadirOrdenada.Text = "Anadir Elemento";
            btnAnadirOrdenada.UseVisualStyleBackColor = true;
            btnAnadirOrdenada.Click += btnAnadirOrdenada_Click_1;
            // 
            // btnBorrarOrdenada
            // 
            btnBorrarOrdenada.Font = new Font("Tahoma", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBorrarOrdenada.Location = new Point(437, 585);
            btnBorrarOrdenada.Name = "btnBorrarOrdenada";
            btnBorrarOrdenada.Size = new Size(254, 29);
            btnBorrarOrdenada.TabIndex = 8;
            btnBorrarOrdenada.Text = "Borrar Elementos";
            btnBorrarOrdenada.UseVisualStyleBackColor = true;
            btnBorrarOrdenada.Click += btnBorrarOrdenada_Click_1;
            // 
            // btnBorrarLstOrdenada
            // 
            btnBorrarLstOrdenada.Font = new Font("Tahoma", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBorrarLstOrdenada.Location = new Point(437, 636);
            btnBorrarLstOrdenada.Name = "btnBorrarLstOrdenada";
            btnBorrarLstOrdenada.Size = new Size(254, 29);
            btnBorrarLstOrdenada.TabIndex = 9;
            btnBorrarLstOrdenada.Text = "Borrar Lista";
            btnBorrarLstOrdenada.UseVisualStyleBackColor = true;
            btnBorrarLstOrdenada.Click += btnBorrarLstOrdenada_Click_1;
            // 
            // lstSinOrdenar
            // 
            lstSinOrdenar.FormattingEnabled = true;
            lstSinOrdenar.Location = new Point(30, 103);
            lstSinOrdenar.Name = "lstSinOrdenar";
            lstSinOrdenar.Size = new Size(253, 424);
            lstSinOrdenar.TabIndex = 12;
            // 
            // lstOrdenada
            // 
            lstOrdenada.FormattingEnabled = true;
            lstOrdenada.Location = new Point(437, 103);
            lstOrdenada.Name = "lstOrdenada";
            lstOrdenada.SelectionMode = SelectionMode.MultiSimple;
            lstOrdenada.Size = new Size(253, 424);
            lstOrdenada.Sorted = true;
            lstOrdenada.TabIndex = 13;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(725, 701);
            Controls.Add(lstOrdenada);
            Controls.Add(lstSinOrdenar);
            Controls.Add(btnBorrarLstOrdenada);
            Controls.Add(btnBorrarOrdenada);
            Controls.Add(btnAnadirOrdenada);
            Controls.Add(btnBorrarLstSinOrdenar);
            Controls.Add(btnBorrarSinOrdenar);
            Controls.Add(btnAnadirSinOrdenr);
            Controls.Add(btnMoveToRight);
            Controls.Add(btnMoveToLeft);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Button btnMoveToLeft;
        private Button btnMoveToRight;
        private Button btnAnadirSinOrdenr;
        private Button btnBorrarSinOrdenar;
        private Button btnBorrarLstSinOrdenar;
        private Button btnAnadirOrdenada;
        private Button btnBorrarOrdenada;
        private Button btnBorrarLstOrdenada;
        private ListBox lstOrdenada;
        private ListBox lstSinOrdenar;
    }
}
