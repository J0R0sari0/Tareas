﻿//Un Supermercado ha puesto en oferta la venta al por mayor de cierto producto, 
//ofreciendo un descuento del 15% por la compra de mas de 3 docenas y un 10% en caso contrario. '
//Además, por la compra de mas de 3 docenas se obsequia una unidad del producto por cada docena en exceso sobre 3. 
//Escriba un programa que deternine monto de compra, el monto del descuento, 
//el monto a pagar y el numero de unidades de obsequio por la compra de cierta cantidad de docenas del producto.

namespace Supermercado
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Titulo de la consola
            Console.Title = "Supermecado oferta venta al mayor";
            //Mensaje de bienvenida
            Console.WriteLine("-/- Oferta Venta al Mayor -/-");
            Console.WriteLine();

            //Almacenar precios de items
            const double Precio_Docena_Donas = 600;

            //Tasa de impuestos
            const double ITBIS = 0.18;

            //Declarar variables
            uint cantidadDonas;

            //Pedir cantidades
            Console.Write("Cantidad de docenas de donas: ");
            cantidadDonas = Convert.ToUInt32(Console.ReadLine());

            //Realizar calculos 

            if (cantidadDonas == 0)
            {
                Console.WriteLine("La cantidad debe ser mayor que cero");
                return;
            }

            double Descuento = 0;
            double subTotalDonas = cantidadDonas * Precio_Docena_Donas;
            if (cantidadDonas > 3)
            {
                Descuento = subTotalDonas * 0.15;
            }
            else if (cantidadDonas <= 3)
            {
                Descuento = subTotalDonas * 0.10;
            }
            double TotalDescuentado = subTotalDonas - Descuento;
            double impuestos = TotalDescuentado * ITBIS;
            double TotalNeto = TotalDescuentado + impuestos;

            //Unidades de Obsequio
            double UnidadesObsequio = 0;
            if (cantidadDonas > 3)
            {
                UnidadesObsequio = (cantidadDonas - 3) * 12;
            }

            Console.WriteLine();

            //Imprimir montos
            Console.WriteLine($"\nEl subtotal de la orden es {subTotalDonas:C}\n");
            Console.WriteLine($"\nEl descuento a aplicar es {Descuento:C}\n");
            Console.WriteLine($"\nEl total de la orden es {TotalNeto:C}\n");
            Console.WriteLine($"Cantidad de unidades de obsequio por compra mayor a 3 docenas: {UnidadesObsequio}");
        }
    }
}