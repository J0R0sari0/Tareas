﻿namespace CalculadoraDeTemperaturas
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtGradosCentigrados = new TextBox();
            txtGradosFahrenheit = new TextBox();
            btnCalcular = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(15, 15);
            label1.Name = "label1";
            label1.Size = new Size(140, 18);
            label1.TabIndex = 0;
            label1.Text = "Grados Centigrados:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(15, 50);
            label2.Name = "label2";
            label2.Size = new Size(132, 18);
            label2.TabIndex = 1;
            label2.Text = "Grados Fahrenheit:";
            // 
            // txtGradosCentigrados
            // 
            txtGradosCentigrados.Location = new Point(162, 15);
            txtGradosCentigrados.Name = "txtGradosCentigrados";
            txtGradosCentigrados.Size = new Size(258, 26);
            txtGradosCentigrados.TabIndex = 2;
            txtGradosCentigrados.KeyPress += txtGradosCentigrados_KeyPress;
            // 
            // txtGradosFahrenheit
            // 
            txtGradosFahrenheit.Location = new Point(162, 50);
            txtGradosFahrenheit.Name = "txtGradosFahrenheit";
            txtGradosFahrenheit.Size = new Size(258, 26);
            txtGradosFahrenheit.TabIndex = 3;
            txtGradosFahrenheit.KeyPress += txtGradosCentigrados_KeyPress;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(162, 91);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(258, 29);
            btnCalcular.TabIndex = 4;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 18F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(440, 138);
            Controls.Add(btnCalcular);
            Controls.Add(txtGradosFahrenheit);
            Controls.Add(txtGradosCentigrados);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Tahoma", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Margin = new Padding(3, 2, 3, 2);
            Name = "Form1";
            Text = "Calculadora de Temperatua";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtGradosCentigrados;
        private TextBox txtGradosFahrenheit;
        private Button btnCalcular;
    }
}
