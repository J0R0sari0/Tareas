namespace CalculadoraDeTemperaturas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            // Validar que solo uno de los campos tenga valor
            if (string.IsNullOrWhiteSpace(txtGradosCentigrados.Text) && string.IsNullOrWhiteSpace(txtGradosFahrenheit.Text))
            {
                MessageBox.Show("Debe ingresar un valor en uno de los campos", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else if (!string.IsNullOrWhiteSpace(txtGradosCentigrados.Text) && !string.IsNullOrWhiteSpace(txtGradosFahrenheit.Text))
            {
                MessageBox.Show("Por favor, escriba el valor en solo uno de los campos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // L�gica de conversi�n seg�n el campo lleno
            if (string.IsNullOrWhiteSpace(txtGradosCentigrados.Text))
            {
                ConvertToCentigrados();
            }
            else
            {
                ConvertToFahrenheit();
            }
        }

        //Centigrados a Fahrenheit
        private void ConvertToFahrenheit()
        {
            try
            {
                double centigrados = double.Parse(txtGradosCentigrados.Text);
                //Formula fahrenheit
                double fahrenheit = (centigrados * 9 / 5) + 32;
                txtGradosFahrenheit.Clear();
                //Muestra el resultado con 2 decimales
                txtGradosFahrenheit.Text = fahrenheit.ToString("F2");
            }
            catch (FormatException)
            {
                MessageBox.Show("Ingrese un numero valido", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //Fahrenheit -> Centigrados
        private void ConvertToCentigrados()
        {
            try
            {
                double fahrenheit = double.Parse(txtGradosFahrenheit.Text);
                //Formula centigrados
                double centigrados = (fahrenheit - 32) * 5 / 9;
                txtGradosCentigrados.Clear();
                txtGradosCentigrados.Text = centigrados.ToString("F2");
            }
            catch (FormatException)
            {
                MessageBox.Show("Ingrese un numero valido", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //Solo permitir numeros enteros o decimales -y negativos- en el textbox
        private void ValidarEntradaNumerica(KeyPressEventArgs e, TextBox textbox)
        {
            //Agregar bloque que permita negativos a codigo anterior
            if (e.KeyChar == '-')
            {
                if (txtGradosCentigrados.SelectionStart != 0 || txtGradosCentigrados.Text.Contains("-"))
                {
                    e.Handled = true;
                }
                return;
            } 

            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // solo 1 punto decimal
            if ((e.KeyChar == '.') && ((txtGradosCentigrados).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        // Eventos KeyPress para ambos TextBox
        private void txtGradosCentigrados_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarEntradaNumerica(e, txtGradosCentigrados);
        }

        private void txtGradosFahrenheit_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarEntradaNumerica(e, txtGradosFahrenheit);
        }
    }
}