﻿using System;

public class Estudiante
{
    private int identificacion;
    private double[] calificaciones;
    private int totalCalificaciones;

    public Estudiante()
    {
        identificacion = 0;
        calificaciones = new double[5];
        totalCalificaciones = 0;
    }

    public void AsignarIdentificacion(int id)
    {
        identificacion = id;
    }

    public void AgregarCalificacion(double calificacion)
    {
        if (totalCalificaciones < 5)
        {
            calificaciones[totalCalificaciones++] = calificacion;
        }
        else
        {
            Console.WriteLine("Ya se han ingresado las 5 calificaciones.");
        }
    }

    public void MostrarPromedio()
    {
        if (totalCalificaciones == 0)
        {
            Console.WriteLine("No hay calificaciones para calcular el promedio.");
            return;
        }

        double suma = 0;
        for (int i = 0; i < totalCalificaciones; i++)
        {
            suma += calificaciones[i];
        }

        double promedio = suma / totalCalificaciones;
        Console.WriteLine($"Estudiante ID: {identificacion} - Promedio: {promedio:F2}");
    }
}

class Program
{
    static void Main()
    {
        Estudiante estudiante = new Estudiante();

        Console.Write("Ingrese la identificacion del estudiante: ");
        if (int.TryParse(Console.ReadLine(), out int id))
        {
            estudiante.AsignarIdentificacion(id);
        }
        else
        {
            Console.WriteLine("Identificacion invalida.");
            return;
        }

        for (int i = 0; i < 5; i++)
        {
            Console.Write($"Ingrese calificacion #{i + 1}: ");
            if (double.TryParse(Console.ReadLine(), out double calificacion))
            {
                estudiante.AgregarCalificacion(calificacion);
            }
            else
            {
                Console.WriteLine("Calificacion invalida. Intentelo nuevamente.");
                i--;
            }
        }

        estudiante.MostrarPromedio();
    }
}
