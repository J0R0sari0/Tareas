﻿using System;

namespace ManejoEmpleado
{
    internal class Program
    {
        static void Main()
        {
            Empleado emp = new Empleado();
            emp.agregarEmpleado();
            emp.showEmployee();
        }
    }
}
