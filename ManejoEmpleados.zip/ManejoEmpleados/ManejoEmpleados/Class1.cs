﻿using System;

namespace ManejoEmpleado
{
    internal class Empleado
    {
        private int id;
        private string name;
        private string apellido;
        private decimal tasaSalarial;
        private uint horasMaximasTrabajadas;
        private bool vip;
        private uint horasTrabajadas;

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Apellido
        {
            get { return apellido; }
            set { apellido = value; }
        }

        public decimal TasaSalarial
        {
            get { return tasaSalarial; }
            set { tasaSalarial = value; }
        }

        public uint HorasMaximasTrabajadas
        {
            get { return horasMaximasTrabajadas; }
            set
            {
                if (value < 0)
                {
                    Console.WriteLine("Las horas maximas trabajadas no pueden ser menor que 0.");
                    horasMaximasTrabajadas = 0;
                }
                else
                {
                    horasMaximasTrabajadas = value;
                }
            }
        }

        public bool VIP
        {
            get { return vip; }
            set { vip = value; }
        }

        public uint HorasTrabajadas
        {
            get { return horasTrabajadas; }
            set
            {
                if (value > horasMaximasTrabajadas)
                {
                    Console.WriteLine("Las horas trabajadas no pueden exceder las horas maximas permitidas.");
                    horasTrabajadas = horasMaximasTrabajadas;
                }
                else
                {
                    horasTrabajadas = value;
                }
            }
        }

        public Empleado()
        {
            Console.WriteLine("Se ha creado un nuevo Empleado...");
        }

        public void agregarEmpleado()
        {
            Console.Write("Enter Employee Id: ");
            Id = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Employee Name: ");
            Name = Console.ReadLine();

            Console.Write("Enter Employee Last Name: ");
            Apellido = Console.ReadLine();

            Console.Write("Enter Employee Pay Rate: ");
            TasaSalarial = Convert.ToDecimal(Console.ReadLine());

            Console.Write("Enter Employee Maximum Hours: ");
            HorasMaximasTrabajadas = Convert.ToUInt32(Console.ReadLine());

            Console.Write("Is Employee VIP? (true/false): ");
            VIP = Convert.ToBoolean(Console.ReadLine());

            Console.Write("Enter Employee Worked Hours: ");
            HorasTrabajadas = Convert.ToUInt32(Console.ReadLine());
        }

        public void agregarEmpleado(int id, string name, string lastName, decimal tasaSalarial, uint horasMaximasTrabajadas, bool vip, uint horasTrabajadas)
        {
            Id = id;
            Name = name;
            Apellido = lastName;
            TasaSalarial = tasaSalarial;
            HorasMaximasTrabajadas = horasMaximasTrabajadas;
            VIP = vip;
            HorasTrabajadas = horasTrabajadas;
        }

        public void modifyEmployee()
        {
            Console.Write("Enter Employee Id: ");
            Id = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Employee Name: ");
            Name = Console.ReadLine();

            Console.Write("Enter Employee Last Name: ");
            Apellido = Console.ReadLine();

            Console.Write("Enter Employee Pay Rate: ");
            TasaSalarial = Convert.ToDecimal(Console.ReadLine());

            Console.Write("Enter Employee Maximum Hours: ");
            HorasMaximasTrabajadas = Convert.ToUInt32(Console.ReadLine());

            Console.Write("Is Employee VIP? (true/false): ");
            VIP = Convert.ToBoolean(Console.ReadLine());

            Console.Write("Enter Employee Worked Hours: ");
            HorasTrabajadas = Convert.ToUInt32(Console.ReadLine());
        }

        public void showEmployee()
        {
            Console.WriteLine($"Employee: {Name} {Apellido}");
            Console.WriteLine($"Employee Id: {Id}");
            Console.WriteLine($"Pay Rate: {TasaSalarial:C}");
            Console.WriteLine($"Maximum Hours: {HorasMaximasTrabajadas}");
            Console.WriteLine($"Worked Hours: {HorasTrabajadas}");
            Console.WriteLine($"VIP: {(VIP ? "Yes" : "No")}");
            Console.WriteLine($"Salary Earned: {CalcularSalario():C}");
        }

        public decimal CalcularSalario()
        {
            decimal salarioBase = TasaSalarial * HorasTrabajadas;
            if (VIP)
            {
                salarioBase *= 1.10m; // 10% extra si es VIP
            }
            return salarioBase;
        }
    }
}
